﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Models
{
    // You can delete this file - just a marker
    public class Marker
    {
    }
}
